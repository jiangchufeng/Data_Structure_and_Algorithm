#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    auto c = a + b;
    cout << c << '\n';
    return 0;
}