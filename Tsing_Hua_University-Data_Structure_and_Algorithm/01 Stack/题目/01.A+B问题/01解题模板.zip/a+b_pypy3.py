#!/usr/bin/env pypy3
a, b = map(int, input().split(' '))
print(a + b)